If you preview the model with Marmoset Toolbag 2 or the trail version, make sure that you have installed the lates version to ensure that the texture load in automatically.



